<?php 
$obj = new adminback();
$links = $obj->display_links();
?>

<div class="header-top bg-main hidden-xs">
    <div class="container">
        <div class="top-bar left">
            <ul class="horizontal-menu">
                <?php 
                while ($link = mysqli_fetch_assoc($links)) { ?>
                    <li>
                        <a class="fa fa-envelope" href="#"> &nbsp;
                            <?php echo $link['email']; ?>
                        </a>
                    </li>
                <?php } ?>
                <li><a href="#">Free Shipping</a></li>
            </ul>
        </div>
        <div class="top-bar right">
            <ul class="social-list">
                <li><a href="#<?php echo $link['tweeter']; ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#<?php echo $link['fb_link']; ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#<?php echo $link['pinterest']; ?>"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
            </ul>
            <ul class="horizontal-menu">
                <?php 
                if (isset($_SESSION['username'])) {
                    echo '
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="biolife-icon icon-user"></i> ' . $_SESSION['username'] . ' <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                            <form action="" method="post">
                                    <button type="submit" name="profile" class="profile-button"><i class="biolife-icon icon-logout"></i> Profile</button>
                                </form>
                            </li>

                            <li>
                                <form action="" method="post">
                                    <button type="submit" name="logout" class="logout-button"><i class="biolife-icon icon-logout"></i> Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>';
                } else {
                    echo '<li><a href="user_login.php" class="login-link"><i class="biolife-icon icon-login"></i> Login</a></li>';
                }
                ?>
            </ul>
        </div>
    </div>
</div>

<?php 
if (isset($_POST['logout'])) {
include_once("admin/class/adminback.php");

    $obj = new adminback();

    $obj->user_logout();
}

if(isset($_POST['profile'])){
    include_once("userprofile.php");

    $obj = new userprofile();
    $obj->userprofile();
}
?>
