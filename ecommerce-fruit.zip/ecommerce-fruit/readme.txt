1. First create a database name ecommerce in your database. Than import ecommerce.sql file in your ecommerce database.

admin access:
vinaymoyal75@gmail.com
pass:1234


user access:
vinaymoyal75@gmail.com
123