<?php 
    $views = "edit_comment";
    include ("template.php");

?>