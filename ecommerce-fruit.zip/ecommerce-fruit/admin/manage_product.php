<?php 
    $views = "manage-product";
    include ("template.php");

?>