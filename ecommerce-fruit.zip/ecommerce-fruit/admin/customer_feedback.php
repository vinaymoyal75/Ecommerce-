<?php 
    $views = "customer_feedback";
    include ("template.php");

?>