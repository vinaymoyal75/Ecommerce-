<?php 
    $views = "add-user";
    include ("template.php");

?>