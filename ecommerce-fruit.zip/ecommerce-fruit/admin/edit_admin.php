<?php 
    $views = "edit_admin";
    include ("template.php");

?>