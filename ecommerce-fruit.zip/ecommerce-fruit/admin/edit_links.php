<?php 
    $views = "edit_links";
    include ("template.php");

?>