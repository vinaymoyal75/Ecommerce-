<?php 
    $views ="make_report";
    include ("template.php");

?>